package com.zplus.companycrud.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Date;

@Getter@Setter@Entity
@Table(name = "order_master")
public class OrderMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(length = 10)
    private Integer orderId;

    @Column(length = 10)
    private String orderNo;

    @Column(length = 5000)
    private String orderBillingAddress;

    @Column(length = 500)
    private String orderDeliveryAddress;

    @Column
    private Double orderTotalCartAmount;

    @Column(length = 50)
    private String orderCouponCode;

    @Column
    private Double orderCouponAmount;

    @Column
    private Double orderTaxAmount;

    @Column
    private Double orderDiscountAmount;

    @Column
    private Double orderFinalAmount;

    @Column(length = 20)
    private String orderStatus;

    @Column(length = 100)
    private String reason;

    @Column
    private Integer orderOtp;

    @Column
    @Temporal(value = TemporalType.DATE)
    private Date orderDate;

    //Added
    private Timestamp orderTimeDate;

    //Added
    private Double deliveryCharges=0.0;

    //Added
    @Column(nullable = false)
    private Boolean orderInvoiceFlag=false;

    @Column(length = 1000)
    private String orderInvoicePath;

    @Column(nullable = false)
    private Boolean vendorInvoiceFlag=false;

    @Column(length = 1000)
    private String vendorInvoicePath;


    private Boolean walletFlag;

    @Column(length = 30)
    private String orderPaymentMode;

    @Column
    private Double deliveryCharge;

    @Column
    private Double usePoint;

    @Column
    private Double useAmount;


}
