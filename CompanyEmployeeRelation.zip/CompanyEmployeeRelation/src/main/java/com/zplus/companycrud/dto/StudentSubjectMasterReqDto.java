package com.zplus.companycrud.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StudentSubjectMasterReqDto {

    private Integer studentSubjectId;
    private Integer studentId;
    private Integer subjectId;

}
