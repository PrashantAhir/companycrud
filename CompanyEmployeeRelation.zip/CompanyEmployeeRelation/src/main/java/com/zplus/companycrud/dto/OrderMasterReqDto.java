package com.zplus.companycrud.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.Date;
@Getter@Setter
public class OrderMasterReqDto {

    private Integer orderId;

    private String orderBillingAddress;

    private String orderDeliveryAddress;

    private Double orderTotalCartAmount;

    private String orderCouponCode;

    private Double orderCouponAmount;

    private Double orderTaxAmount;

    private Double orderDiscountAmount;

    private Double orderFinalAmount;

    private String orderStatus;

    private Date orderDate;

    private String orderPaymentMode;

    private Integer customerId;

    private Integer vendorId;

    private Integer cartId;

//    private List<CartResDto> cartResDtoList;

    private Double deliveryCharge;

    private Double orderTotalAmount;

    private Double usePoint;

    private Double useAmount;

    private String customerName;
    private String mobileNumber;
    private String email;
    private Double deliveryCharges;
    private Boolean walletFlag;
}
